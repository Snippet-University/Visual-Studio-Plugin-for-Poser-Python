import poser

scene=poser.Scene()

fileMenu		={	'Exit'							:	1		,
					'New'							:	2		,
					'Open'							:	3		,
					'Close'							:	4		,
					'Save'							:	5		,
					'Save As'						:	6		,
					'Revert'						:	7		,
					'Page Setup'					:	8		,
					'Print'							:	9		}

importMenu		={	'Import Background Image'		:	1115	,
					'Import Poser Documnet Prop'	:	1131	,
					'Import Video'					:	1363	,
					'Import BVH Motion'				:	1383	,
					'Import PHI'					:	1389	, #Convert Hier File
					'Import Sound'					:	1401	,
					'Run Python Script'				:	1506	,
					'Import LipSync'				:	1567	}

exportMenu		={	'Export RIB'					:	1158	,
					'Export Image'					:	1192	,
					'Export BVH Motion'				:	1403	}

editMenu		={	'Undo'							:	16		,
					'Redo'							:	17		,
					'Cut'							:	18		,
					'Copy'							:	19		,
					'Paste'							:	20		,
					'Duplicate Object \ Figure'		:	1568	}

restoreMenu		={	'Restore Element'				:	1036	,
					'Restore All'					:	1043	,
					'Restore Lights'				:	1106	,
					'Restore Figure'				:	1107	,
					'Restore Camera'				:	1275	}

memorizeMenu	={	'Memorize Element'				:	1277	,
					'Memorize Figure'				:	1278	,
					'Memorize Camera'				:	1279	,
					'Memorize Lights'				:	1280	,
					'Memorize All'					:	1281	}

figureMenu		={	'Use Limits'					:	1089	,
					'Straighten Torso'				:	1112	,
					'Hide Figure'					:	1133	,
					'Show All Figures'				:	1134	,
					'Delete Figure'					:	1135	,
					'Height Adolescent'				:	1148	,
					'Height Ideal Adult'			:	1149	,
					'Height Fashion Model'			:	1150	,
					'Height Baby'					:	1152	,
					'Height Toddler'				:	1153	,
					'Height Child'					:	1154	,
					'Height Juvenile'				:	1155	,
					'Height Heroic Model'			:	1156	,
					'Drop To Floor'					:	1205	,
					'Genitalia'						:	1370	,
					'Auto Balance'					:	1394	,
					'Create Walk Path'				:	1400	,
					'Set Figure Parent'				:	1402	,
					'Lock Hand Parts'				:	1442	,
					'Conform To'					:	1475	,
					'Lock Figure'					:	1492	,
					'Create FBM'					:	1484	}

mirrorMenu		={	'Left To Right'					:	1074	,
					'Right To Left'					:	1075	,
					'Right Arm to Left Arm'			:	1108	,
					'Left Arm to Right Arm'			:	1110	,
					'Left Leg to Right Leg'			:	1111	,
					'Swap Right and Left Arms'		:	1371	,
					'Swap Right and Left Legs'		:	1372	,
					'Swap Right and Left'			:	1373	}

displayMenu		={	'Depth Cued'					:	1044	,
					'Show Background Picture'		:	1051	,
					'Paste onto Background'			:	1052	, 
					'Clear Background Picture'		:	1053	,
					'Bend Body Parts'				:	1216	,
					'Background Color'				:	1269	,
					'Foreground Color'				:	1270	,
					'Show Background Footage'		:	1361	,
					'Clear Background Footage'		:	1362	,
					'Ground Shadows'				:	1406	,
					'Figure Circle'					:	1460	,
					'Use Background Shader Node'	:	1533	}

objectMenu		={	'Delete Object'					:	1255	,
					'Change Parent'					:	1294	,
					'Replace Body Part with prop'	:	1304	,
					'Object Properties'				:	1378	,
					'Create Magnet'					:	1462	,
					'Create Wave'					:	1468	,
					'Spawn Morph Target'			:	1483	,
					'Load Morph Target'				:	1485	,
					'Point At'						:	1487	,
					'Lock Actor'					:	1497	}

lightMenu		={	'Create Spot Light'				:	1479	,
					'Create Infinite Light'			:	1570	,
					'Create Point Light'			:	1571	,
					'Create Diffuse IBL'			:	1572	}

cameraMenu		={	'Create Wind Force'				:	1528	,
					'Create Revolving Camera'		:	1565	,
					'Create Dolly Camera'			:	1566	}

viewMenu		={	'Main Camera'					:	1024	,
					'From Front'					:	1027	,
					'From Top'						:	1028	,
					'From Right'					:	1029	,
					'From Left'						:	1374	,
					'Dolly Camera'					:	1375	,
					'Posing Camera'					:	1376	,
					'Left Hand Camera'				:	1396	,
					'Right Hand Camera'				:	1397	,
					'Face Camera'					:	1398	,
					'Fly Around'					:	1399	,
					'Aux Camera'					:	1480	,
					'From Bottom'					:	1481	,
					'From Back'						:	1482	}

layoutMenu		={	'Four Cameras'					:	1062	,
					'Show Camera Names'				:	1519	}

documentStyle	={	'Wireframe'						:	1030	,
					'Outline'						:	1040	,
					'Silhouette'					:	1041	,
					'Hidden Line'					:	1045	,
					'Smooth Shaded'					:	1083	,
					'Lit Wireframe'					:	1084	,
					'Flat Shaded'					:	1392	,
					'Cartoon with Lines'			:	1393	,
					'Texture Shaded'				:	1410	,
					'Smooth Shaded Lined'			:	1497	,
					'Flat Shaded Lined'				:	1499	,
					'Cartoon'						:	1501	}

objectStyle		={	'Texture Shaded'				:	1409	,
					'Wireframe'						:	1421	,
					'Outline'						:	1422	,
					'Silhouette'					:	1423	,
					'Hidden Line'					:	1424	,
					'Smooth Shaded'					:	1425	,
					'Lit Wireframe'					:	1426	,
					'Cartoon with Lines'			:	1427	,
					'Flat Shaded'					:	1428	,
					'Use Figure Style'				:	1429 	,
					'Flat Shaded Lined'				:	1493	,
					'Smooth Shaded Lined'			:	1494	,
					'Cartoon'						:	1495	}

trackingMenu	={	'Fast Tracking'					:	1031	,
					'Bounding Boxes Only'			:	1092	,
					'Full Tracking'					:	1420	}

deformersMenu	={	'Show All'						:	1470	,
					'Hide All'						:	1471	,
					'Show Current Selection only'	:	1472	}

guidesMenu		={	'Ground Plane'					:	1047	,
					'Head Lengths'					:	1048	,
					'Hip \ Shoulder Relationship'	:	1049	,
					'Vanishing Lines' 				:	1050	,
					'Horizon Line'					:	1146	,
					'Focus Distance Guide'			:	1548	}

previewMenu		={	'OpenGL Hardware'				:	1550	,
					'Sreed Software'				:	1551	}

cartoontonesMenu={	'One Tone'						:	1552	,
					'Two Tones'						:	1553	,
					'Three Tones'					:	1554	,
					'Four Tones'					:	1555	,
					'Smooth Toned'					:	1557	}

renderMenu		={	'Render Settings'				:	1225	,
					'Materials'						:	1265	,
					'Render'						:	1267	,
					'Make Movie'					:	1312	,
					'AntiAlias Document'			:	1461	,
					'Sketch Style Render'			:	1466	,
					'MotionBlur Document'			:	1508	,
					'Reload Textures'				:	1559	,
					'Reuse Shadow Maps'				:	1560	,
					'Clear Shadow Maps'				:	1561	,
					'Area Render'					:	1562	,
					'Render Dimensions'				:	1563	}

dynamicsMenu	={	'Recalculate All Cloth and Hair':	1535	,
					'Recalculate All Cloth'			:	1536	,
					'Recalculate All Hair'			:	1537	}

animationMenu	={	'Retime Animation'				:	1380	,
					'Loop Interpolation'			:	1395	,
					'Resample Key Frames'			:	1404	,
					'Quaternion Interpolation'		:	1405	,
					'Play Movie File'				:	1407	,
					'Mute Sound'					:	1413	,
					'Clear Sound'					:	1414	,
					'Skip Frames'					:	1415	}

windowMenu		={	'Animation Palette'				:	1176	,
					'Parameter Dials'				:	1178	,
					'Libraries'						:	1201	,
					'Document Window Size'			:	1204	,
					'Editing Tools'					:	1274	,
					'Joint Editor'					:	1387	,
					'Walk Designer'					:	1390	,
					'Graph'							:	1391	,
					'Camera Controls'				:	1416	,
					'Light Controls'				:	1417	,
					'Memory Dots'					:	1419	,
					'Preview Styles'				:	1418	,
					'Animation Controls'			:	1459	,
					'Sketch Designer'				:	1465	,
					'Hierarchy Editor'				:	1488	,
					'Python Scripts'				:	1509	,
					'Room Help'						:	1522	,
					'Talk Designer'					:	1569	,
					'Quick Start'					:	1573	,
					'Project Guide'					:	1574	,
					'Recent Renders'				:	1601	}

materialroomMenu={	'Material Palette'				:	1583	}

faceroomMenu	={	'Face Preview'					:	1584	,
					'Photo Lineup'					:	1585	,
					'Texture Preview'				:	1586	,
					'Face Texture Tool'				:	1587	,
					'Face Shaping Tool'				:	1588	}

hairRoomMenu	={	'Hair Growth Groups'			:	1589	,
					'Growth Controls'				:	1590	,
					'Styling Controls'				:	1591	,
					'Dynamics Controls'				:	1592	}

clothroomMenu	={	'Cloth Simulation'				:	1593	,
					'Cloth'							:	1594	,
					'Cloth Groups'					:	1595	,
					'Dynamics Controls'				:	1596	}

scriptsMenu		={	'Personalise'					:	59996	,
					'Poser Reference Manual'		:	59997	,
					'poser Tutorial Manual'			:	59998	,
					'Poser Python manual'			:	59999	,
					'About Poser'					:	5014	,
	
}
# selectcommand by Dictionary
# poser.ProcessCommand(restoreMenu['Restore Figure'])
poser.ProcessCommand(renderMenu['Render'])
poser.ProcessCommand(exportMenu['Export Image'])
# select command by number 
#poser.ProcessCommand(5022)
# for r in renderMenu:
# 	print r